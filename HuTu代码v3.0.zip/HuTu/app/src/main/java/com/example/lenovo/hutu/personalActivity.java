package com.example.lenovo.hutu;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by lenovo on 2017/4/18.
 */

public class personalActivity extends Activity {
    private Button diaryButton;
    private Button paintButton;
    private TextView userinfo;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.personal);
        Intent i=getIntent();
        name=i.getStringExtra("username");

        diaryButton=(Button)findViewById(R.id.diarybutton);
        paintButton=(Button)findViewById(R.id.paintBut);
        userinfo=(TextView)findViewById(R.id.userInfo);

        userinfo.setText(name+"欢迎来到糊涂神");
        diaryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent diary = new Intent(personalActivity.this,diarylistActivity.class);
                diary.putExtra("username",name);
                startActivity(diary);

            }
        }

        );
        paintButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent paint=new Intent(personalActivity.this,paintActivity.class);
                paint.putExtra("username",name);
                startActivity(paint);
            }
        });
    }
}
