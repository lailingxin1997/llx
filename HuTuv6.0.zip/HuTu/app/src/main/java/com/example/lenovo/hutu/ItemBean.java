package com.example.lenovo.hutu;

import java.io.Serializable;

/**
 * Created by molly on 2017/5/12.
 */

public class ItemBean implements Serializable{
    public String ItemTitle;
    public String ItemCost;
    public String ItemDate;
    public String ItemCate;

    }

