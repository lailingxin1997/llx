package com.example.lenovo.hutu;

/**
 * Created by lenovo on 2017/5/6.
 */

public class day {

        private String username;
        private String date;
        private String title;
        private String weather;
        private String content;

        public day(String date,String title,String weather,String username,String content)
        {
            this.date=date;
            this.title=title;
            this.weather=weather;
            this.content=content;
            this.username=username;
        }
        public String getDate()
        {
            return date;
        }

        public String getTitle() {
            return title;
        }

        public String getWeather() {
            return weather;
        }

        public String getUsername(){return username;}

    public String getContent() {
        return content;
    }
}
