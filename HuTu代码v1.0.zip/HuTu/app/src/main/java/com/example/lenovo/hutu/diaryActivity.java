package com.example.lenovo.hutu;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by lenovo on 2017/4/18.
 */

public class diaryActivity extends Activity {
    private Button save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        save=(Button)findViewById(R.id.savebut);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diary);
    }
}
