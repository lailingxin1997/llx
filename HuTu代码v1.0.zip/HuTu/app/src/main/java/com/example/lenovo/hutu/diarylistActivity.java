package com.example.lenovo.hutu;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import java.util.HashMap;

/**
 * Created by lenovo on 2017/5/5.
 */

public class diarylistActivity extends Activity {
    private Button adddiary;
    Cursor diaries;
    TextView textView=null;
    ListView list;
    private final String Tag="断点";
    @Override
    protected void onCreate(Bundle SavedInstanceState)
    {
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.loglist);
        list=(ListView)findViewById(R.id.diarylist);
        Log.i(Tag,"chenggong");
        refreshList();
        //this.registerForContextMenu(diarylist);
        adddiary=(Button)findViewById(R.id.additem);
        adddiary.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent diary = new Intent(diarylistActivity.this,diaryActivity.class);
                startActivity(diary);
            }
        });
    }
    public void refreshList(){
        DiaryDao diaryDao = new DiaryDao(this);
        diaries =diaryDao.getAllDairies();
        SimpleCursorAdapter simpleCursorAdapter=new SimpleCursorAdapter(diarylistActivity.this,
                R.layout.listitem,diaries,new String[]{"title","created"},new int[]{R.id.content,R.id.date});
       list.setAdapter(simpleCursorAdapter);
    }
}
