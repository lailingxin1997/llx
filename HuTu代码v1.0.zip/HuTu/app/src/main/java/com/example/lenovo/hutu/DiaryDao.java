package com.example.lenovo.hutu;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;

import static com.example.lenovo.hutu.R.id.date;
import static com.example.lenovo.hutu.R.id.username;

/**
 * Created by lenovo on 2017/5/6.
 */

public class DiaryDao {
    private Sqliteopenhelper sqliteopenhelper;
    private SQLiteDatabase sqLiteDatabase;

    public DiaryDao(Context context){
        sqliteopenhelper=new Sqliteopenhelper(context);
    }
    public void save(day diary,String title,String content,String weather,String username,String date){
        SQLiteDatabase personalDB=sqliteopenhelper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("_username",username);
        values.put("title",title);
        values.put("weather",weather);
        values.put("date",date);
        values.put("content",content);
        personalDB.insert("logItem",null,values);
    }
    public long count(){
        long count=0;
        sqLiteDatabase=sqliteopenhelper.getReadableDatabase();
        Cursor cursor=sqLiteDatabase.rawQuery("select count(*) from diary ",null
        );
        cursor.moveToFirst();
        count=cursor.getLong(0);
        return count;
    }
    public Cursor getAllDairies(){
        sqLiteDatabase = sqliteopenhelper.getReadableDatabase();
        Cursor cursor=sqLiteDatabase.rawQuery("select * from diary ",null);
        return cursor;
    }
}
