package com.example.lenovo.hutu;

import android.app.Activity;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.text.SimpleDateFormat;

import java.sql.Time;
import java.util.Date;


/**
 * Created by lenovo on 2017/4/18.
 */

public class diaryActivity extends Activity {
    DiaryDao diaryDao = new DiaryDao(diaryActivity.this);
    private EditText content,title,weather,created;
    private String contentstr,titlestr,weatherstr,createdstr,usernamestr,newcreatedstr;
    private Button save;
    private String edit;
    private int oldid;
    private final String Tag="检查";
    private String oldtime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diary);
        Intent i=getIntent();
        usernamestr=getIntent().getStringExtra("username");
        SimpleDateFormat theformat=new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
        Date current=new Date(System.currentTimeMillis());
        String str=theformat.format(current);
        content=(EditText)findViewById(R.id.fullcontent);
        title=(EditText)findViewById(R.id.fulltitle);
        weather=(EditText)findViewById(R.id.fullweather);
        created=(EditText)findViewById(R.id.created);
        created.setEnabled(false);
        edit=i.getStringExtra("isEdit");
        Log.v(Tag,edit);

        if (edit.equals("yes")==true){
            oldid=i.getIntExtra("id",-1);
            createdstr=i.getStringExtra("created");
            Log.v(Tag,oldid+"");
            Log.v(Tag,createdstr+"");
            day day=diaryDao.getDayByCreated(createdstr,usernamestr);
            content.setText(day.getContent());
            title.setText(day.getTitle());
            weather.setText(day.getWeather());
            //created.setEnabled(true);
            created.setText(createdstr);
          //  created.setEnabled(false);
        }
        else if (edit.equals("no")==true)
        {
            created.setText(str);
        }

save=(Button)findViewById(R.id.savebut);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                     getText();
                    day day = new day(newcreatedstr, titlestr, weatherstr, usernamestr, contentstr);

                    Log.v(Tag, edit);
                    if (edit.equals("yes") == true) {
                        Log.v(Tag, "进入更新");
                        oldtime=createdstr;
                        diaryDao.update(day,oldtime, usernamestr, oldid);


                    } else {
                        diaryDao.save(day, usernamestr);
                    }
                    Intent i = new Intent(diaryActivity.this, diarylistActivity.class);
                    i.putExtra("username", usernamestr);
                    startActivity(i);


                 }
        });

    }

    private void getText(){

        Log.v(Tag,usernamestr);
        contentstr=content.getText().toString();
        Log.v(Tag,contentstr);
        titlestr=title.getText().toString();
        Log.v(Tag,titlestr);
        weatherstr=weather.getText().toString();
        Log.v(Tag,weatherstr);
        newcreatedstr=created.getText().toString();
        Log.v(Tag,newcreatedstr);
    }
}
