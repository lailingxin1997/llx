package com.example.lenovo.hutu;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by lenovo on 2017/5/6.
 */

public class DiaryDao {
    private Sqliteopenhelper sqliteopenhelper;
    private SQLiteDatabase sqLiteDatabase;

    public DiaryDao(Context context){
        sqliteopenhelper=new Sqliteopenhelper(context);
    }
    public void save(day day){
        SQLiteDatabase personalDB=sqliteopenhelper.getWritableDatabase();
        int id=0;
        id=getid();
        ContentValues values=new ContentValues();
        values.put("username",day.getUsername());
        values.put("title",day.getTitle());
        values.put("weather",day.getWeather());
        values.put("created",day.getCreated());
        values.put("content",day.getContent());
        values.put("_id",id);
        personalDB.insert("diary",null,values);

    }
    public void update(day day,int id){
        sqLiteDatabase =sqliteopenhelper.getWritableDatabase();// 得到的是同一个数据库实例
        sqLiteDatabase.execSQL(
                "update diary set username=?,title=?,created=? ,weather=?,content=? where _id=?",
                new Object[] { day.getUsername(),day.getTitle(), day.getCreated(),day.getWeather(),day.getContent(),
                       id });
    }
    public int count(){
        int count=0;
        sqLiteDatabase=sqliteopenhelper.getReadableDatabase();
        Cursor cursor=sqLiteDatabase.rawQuery("select count(*) from diary ",null
        );
        cursor.moveToFirst();
        count=cursor.getInt(0);
        return count;
    }
    public Cursor getAllDairies(){
        sqLiteDatabase = sqliteopenhelper.getReadableDatabase();
        Cursor cursor=sqLiteDatabase.rawQuery("select * from diary ",null);
        return cursor;
    }
    public int getid(){
        int id=0;
        id=count()+1;
        return id;

    }
    public Cursor findCursor()
    {
        sqLiteDatabase=sqliteopenhelper.getWritableDatabase();
        Cursor c=sqLiteDatabase.rawQuery("select _id as username,title,weather,content,created,username from diary",null);
        return c;
    }
    public day getDayById(int id)
    {
        sqLiteDatabase=sqliteopenhelper.getWritableDatabase();
        day day=null;
        Cursor cursor=sqLiteDatabase.rawQuery("select * " +
                "from diary where _id=?",new String[]{id+""});
        if (cursor.moveToFirst()){

            String title=cursor.getString(cursor.getColumnIndex("title"));
            String created=cursor.getString(cursor.getColumnIndex("created"));
            String weather=cursor.getString(cursor.getColumnIndex("weather"));
            String content=cursor.getString(cursor.getColumnIndex("content"));
            String username=cursor.getString(cursor.getColumnIndex("username"));
            day=new day(created,title,weather,username,content);
        }
        return  day;
    }

}
