package com.example.lenovo.hutu;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by lenovo on 2017/4/18.
 */

public class diaryActivity extends Activity {
    DiaryDao diaryDao = new DiaryDao(diaryActivity.this);
    private EditText content,title,weather,created;
    private String contentstr,titlestr,weatherstr,createdstr,usernamestr;
    private Button save;
    private String edit;
    private int oldid;
    private final String Tag="检查";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diary);
        Intent i=getIntent();
        content=(EditText)findViewById(R.id.fullcontent);
        title=(EditText)findViewById(R.id.fulltitle);
        weather=(EditText)findViewById(R.id.fullweather);
        created=(EditText)findViewById(R.id.created);
        edit=i.getStringExtra("isEdit");
        Log.v(Tag,edit);
        if (edit.equals("yes")){
            oldid=i.getIntExtra("id",-1);
            Log.v(Tag,oldid+"");
            day day=diaryDao.getDayById(oldid);
            content.setText(day.getContent());
            title.setText(day.getTitle());
            weather.setText(day.getWeather());
            created.setText(day.getCreated());

        }

save=(Button)findViewById(R.id.savebut);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    getText();
                day day = new day(createdstr, titlestr, weatherstr, usernamestr, contentstr);
                if (edit.equals("yes")){
                    diaryDao.update(day,oldid);
                }

                    diaryDao.save(day);

                    Intent i = new Intent(diaryActivity.this, diarylistActivity.class);
                    startActivity(i);

            }
        });

    }
    private void getText(){
        usernamestr="ritawo";
        Log.v(Tag,usernamestr);
        contentstr=content.getText().toString();
        Log.v(Tag,contentstr);
        titlestr=title.getText().toString();
        Log.v(Tag,titlestr);
        weatherstr=weather.getText().toString();
        Log.v(Tag,weatherstr);
        createdstr=created.getText().toString();
        Log.v(Tag,createdstr);
    }
}
