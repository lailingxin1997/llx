package com.example.lenovo.hutu;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by lenovo on 2017/4/22.
 */

public class paintActivity extends Activity {

    private ImageView iv;
    private Button pickColor;
    private Bitmap baseBitmap;
    private Canvas canvas;
    private Paint paint;
    private colorDialog dialog;
    private DisplayMetrics dm;
    Context context;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        context=this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.paint);
        iv = (ImageView) findViewById(R.id.imageView6);
        dm=new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int hight=dm.heightPixels;
        int width=dm.widthPixels;
        baseBitmap=Bitmap.createBitmap(width,hight, Bitmap.Config.ARGB_8888);
        canvas = new Canvas(baseBitmap);
        canvas.drawColor(Color.WHITE);
        paint = new Paint();
        paint.setStrokeWidth(5);
        paint.setColor(Color.GREEN);
        // 创建一个可以被修改的bitmap


        // 知道用户手指在屏幕上移动的轨迹
        iv.setOnTouchListener(new View.OnTouchListener() {
            // 设置手指开始的坐标
            int startX;
            int startY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: // 手指第一次接触屏幕
                        startX = (int) event.getX();
                        startY = (int) event.getY();
                        break;
                    case MotionEvent.ACTION_MOVE:// 手指在屏幕上滑动
                        int newX = (int) event.getX();
                        int newY = (int) event.getY();

                        canvas.drawLine(startX, startY, newX, newY, paint);
                        // 重新更新画笔的开始位置
                        startX = (int) event.getX();
                        startY = (int) event.getY();
                        iv.setImageBitmap(baseBitmap);
                        break;
                    case MotionEvent.ACTION_UP: // 手指离开屏幕
                        break;

                    default:
                        break;
                }
                return true;
            }
        });
        pickColor = (Button) findViewById(R.id.pickColor);
        pickColor.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog = new colorDialog(context, Color.BLUE, new colorDialog.OnColorChangedListener() {
                    @Override
                    public void colorChanged(int color) {
                    paint.setColor(color);

                    }

                });

                dialog.show();
            }
        });
}




}
