package com.example.lenovo.hutu;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static android.R.attr.id;

/**
 * Created by lenovo on 2017/5/5.
 */

public class diarylistActivity extends Activity implements AdapterView.OnItemClickListener{
    private Button adddiary;
    Cursor diaries;
    TextView textView=null;
    ListView list;
    private  Cursor cursor;
    SimpleCursorAdapter simpleCursorAdapter=null;
    private  DiaryDao diaryDao ;
    private final String Tag="断点";
    @Override
    protected void onCreate(Bundle SavedInstanceState)
    {
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.loglist);
        list=(ListView)findViewById(R.id.diarylist);
        Log.i(Tag,"chenggong");
        refreshList();
        cursor=diaryDao.findCursor();
        list.setOnItemClickListener(this);
        //this.registerForContextMenu(diarylist);
        adddiary=(Button)findViewById(R.id.additem);
        adddiary.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent diary = new Intent(diarylistActivity.this,diaryActivity.class);
                diary.putExtra("isEdit","no");
                startActivity(diary);
            }
        });
    }
    public void refreshList(){
        diaryDao = new DiaryDao(this);
        diaries =diaryDao.getAllDairies();
        simpleCursorAdapter=new SimpleCursorAdapter(diarylistActivity.this,
                R.layout.listitem,diaries,new String[]{"title","created","_id"},new int[]{R.id.content,R.id.created,R.id.diaryid});
        list.setAdapter(simpleCursorAdapter);
    }

    @Override
    public void onResume(){
        super.onResume();
        refreshList();
    }
    @Override
    public  void onItemClick(AdapterView<?> parent,View view,
                             int position,long args){
        Intent i = new Intent(diarylistActivity.this,diaryActivity.class);
        int id=(int)parent.getItemIdAtPosition(position) ;
        diaryDao = new DiaryDao(this);
       // day day=diaryDao.getDayById(id);
        i.putExtra("isEdit","yes");
        i.putExtra("id",id);
        startActivity(i);

    }
}
