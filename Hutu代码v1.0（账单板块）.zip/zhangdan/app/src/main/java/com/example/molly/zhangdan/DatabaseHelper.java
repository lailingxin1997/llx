package com.example.molly.zhangdan;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by molly on 2017/5/12.
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    private DatabaseHelper helper;
    public DatabaseHelper(Context context) {
        super(context, "bill", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
         db.execSQL("create table if not exists bill(_billID integer primary key autoincrement," +
                 "Money varchar[20]," +
                 "Date varchar[20]," +
                 "title varchar[20]," +
                 "category varchar[20],"+
                 "UserID varchar[20])");
    }
    public void insertbill(ItemBean itemBean){
        SQLiteDatabase Database=getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("Money",itemBean.ItemCost);
        cv.put("Date",itemBean.ItemDate);
        cv.put("title",itemBean.ItemTitle);
        cv.put("category",itemBean.ItemCate);
        Database.insert("bill",null,cv);
    }
    public Cursor getallBilldata(){
        SQLiteDatabase Database=getWritableDatabase();
        return Database.query("bill",null,null,null,null,null,"Date");
    }
    public void deleteAlldata(){
        SQLiteDatabase Database=getWritableDatabase();
        Database.delete("bill",null,null);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void delete(String Money,String Date,String title,String category ) {
        SQLiteDatabase Database=getWritableDatabase();
        Database.execSQL("delete from bill where Money=? and Date=? and title=? and category=? ", new Object[]{Money,Date,title,category});

    }
}
