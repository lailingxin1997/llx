package com.example.molly.zhangdan;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.view.View;
import android.content.Intent;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import static android.R.id.list;

/**
 * Created by molly on 2017/5/9.
 */

public class Bill_mainActivity extends Activity {
    private Button bn,deduct,tran_chart;

    public DatabaseHelper mDatabaseHelper;
    public List<ItemBean> mItemBean;
    public MyAdapter myAdapter;
    public double sum;
    public double nowcost;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bill_main);

        mDatabaseHelper = new DatabaseHelper(this);
        mItemBean = new ArrayList<>();
        final ListView listView = (ListView) findViewById(R.id.lv_main);
        final EditText allcost=(EditText) findViewById(R.id.sumcost);
        RelativeLayout main= (RelativeLayout) findViewById(R.id.bill_main);
        String s=allcost.getText().toString();
        sum=Double.parseDouble(s);

        //关闭edittext的软键盘（有焦点时）
        allcost.setOnTouchListener(new View.OnTouchListener() {

            public boolean onTouch(View v, MotionEvent event) {

                allcost.setInputType(InputType.TYPE_NULL); // 关闭软键盘

                return false;

            }

        });
        //关闭edittext的软键盘（无焦点时）
        InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(allcost.getWindowToken(), 0);

        //读取从sec中传递过来的新增条目
        final Bundle bundle = getIntent().getBundleExtra("bundle");
        String key = bundle.getString("key");
        if (key.equals("sec")) {
            String cost = bundle.getString("cost");
            String date = bundle.getString("date");
            String title = bundle.getString("title");
            String Cate=bundle.getString("Cate");
            if ((title != null) || (date != null) || (cost != null)) {
                ItemBean itemBean1 = new ItemBean();
                itemBean1.ItemCost = cost;
                itemBean1.ItemDate = date;
                itemBean1.ItemTitle = title;
                itemBean1.ItemCate=Cate;
                mDatabaseHelper.insertbill(itemBean1);
               // mItemBean.add(itemBean1);
                //myAdapter.notifyDataSetChanged();
            }
        }
        //初始化itemlist

        InitBilldata();
        DecimalFormat df1 = new DecimalFormat("0.00");
        //设置总体金额

        allcost.setText(df1.format(sum));
        if(sum>1000){
            main.setBackgroundColor(Color.parseColor("#00CC00"));
        }
        else if((sum<=1000)&&(sum>500)){
            main.setBackgroundColor(Color.parseColor("#99CC33"));
        }
        else if((sum<=500)&&(sum>200)){
            main.setBackgroundColor(Color.parseColor("#E3CF57"));
        }
        else if((sum<=200)&&(sum>50)){
            main.setBackgroundColor(Color.parseColor("#FF9912"));
        }
        else if((sum<=50)&&(sum>0)){
            main.setBackgroundColor(Color.parseColor("#FF9900"));
        }
        else if((sum<=0)&&(sum>-100)){
            main.setBackgroundColor(Color.parseColor("#FF6600"));
        }
        else if((sum<=-100)&&(sum>-200)){
            main.setBackgroundColor(Color.parseColor("#FF8000"));
        }
        else if((sum<=-200)&&(sum>-500)){
            main.setBackgroundColor(Color.parseColor("#FF4500"));
        }
        else if((sum<=-500)&&(sum>-1000)){
            main.setBackgroundColor(Color.parseColor("#FF6100"));
        }
        else if(sum<=-1000){
            main.setBackgroundColor(Color.parseColor("#FF6347"));
        }
        myAdapter = new MyAdapter(this, mItemBean);
        listView.setAdapter(myAdapter);
        bn = (Button) findViewById(R.id.add);
        bn.setOnClickListener(new View.OnClickListener() {//创建监听
            public void onClick(View v) {
                Intent inten = new Intent(Bill_mainActivity.this, Bill_secActivity.class);
                Bundle main_bundle = new Bundle();
                main_bundle.putString("key", "add");
                inten.putExtra("bundle", main_bundle);
                startActivity(inten);
            }
        });
        deduct = (Button) findViewById(R.id.deduct);
        deduct.setOnClickListener(new View.OnClickListener() {//创建监听
            public void onClick(View v) {
                Intent inten1 = new Intent(Bill_mainActivity.this, Bill_secActivity.class);
                Bundle main_bundle = new Bundle();
                main_bundle.putString("key", "deduct");
                inten1.putExtra("bundle", main_bundle);
                startActivity(inten1);
            }
        });
        tran_chart=(Button)findViewById(R.id.trans_chart);
        tran_chart.setOnClickListener(new View.OnClickListener() {//创建监听
            public void onClick(View v) {
                Intent inten6= new Intent(Bill_mainActivity.this, Charts1Activity.class);
                inten6.putExtra("cost_list", (Serializable) mItemBean);
                startActivity(inten6);
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(Bill_mainActivity.this,Bill_secActivity.class);
                ItemBean itemBean = mItemBean.get(position);
                
                Bundle bundle = new Bundle();
                bundle.putString("Cate",itemBean.ItemCate);
                bundle.putString("title",itemBean.ItemTitle);
                bundle.putString("date",itemBean.ItemDate);
                bundle.putString("cost",itemBean.ItemCost);
                bundle.putString("key","item");
                
                intent.putExtra("bundle",bundle);
                mDatabaseHelper.delete(itemBean.ItemCost,itemBean.ItemDate,itemBean.ItemTitle,itemBean.ItemCate);
                startActivity(intent);
            }
        });

    }



    private void InitBilldata() {

        Cursor cursor=mDatabaseHelper.getallBilldata();
       if(cursor!=null){
           while (cursor.moveToNext()){
               ItemBean itemBean=new ItemBean();
               itemBean.ItemTitle=cursor.getString(cursor.getColumnIndex("title"));
               itemBean.ItemDate=cursor.getString(cursor.getColumnIndex("Date"));
               itemBean.ItemCost=cursor.getString(cursor.getColumnIndex("Money"));
               itemBean.ItemCate=cursor.getString(cursor.getColumnIndex("category"));
                mItemBean.add(itemBean);
               if( itemBean.ItemCate.equals("add")){
                   sum=sum+Double.parseDouble(itemBean.ItemCost);
               }
               else{
                   sum=sum-Double.parseDouble(itemBean.ItemCost);
               }
            }
            cursor.close();
       }
   }
}
