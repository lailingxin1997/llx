package com.example.molly.zhangdan;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * Created by molly on 2017/5/12.
 */

public class ItemBean implements Serializable{
    public String ItemTitle;
    public String ItemCost;
    public String ItemDate;
    public String ItemCate;

    }

